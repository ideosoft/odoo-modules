Account Move Line Payable Receivable Filter
===========================================

This module was written to extend the functionality of search on journal items
to allow you to filter by payable and receivable account

Installation
============

To install this module, you need to:

 * Click on install button

Usage
=====

To use this module, you need to:

 * go to Journal Items view and select new filter

For further information, please visit:

 * https://www.odoo.com/forum/help-1


Credits
=======

Contributors:
-------------

* Stéphane Bidoul (ACSONE) <stephane.bidoul@acsone.eu>
* Adrien Peiffer (ACSONE) <adrien.peiffer@acsone.eu>

Maintainer:
-----------

.. image:: http://odoo-community.org/logo.png
   :alt: Odoo Community Association
   :target: http://odoo-community.org

This module is maintained by the OCA.

OCA, or the Odoo Community Association, is a nonprofit organization whose mission is to support the collaborative development of Odoo features and promote its widespread use.

To contribute to this module, please visit http://odoo-community.org.
