Account Reversal
================

This module adds an action "Reversal" on account moves,
to allow the accountant to create reversal account moves in 2 clicks.
Also add on account entries:

 * a checkbox and filter "to be reversed"
 * a link between an entry and its reversal entry

Module originally developped by Alexis de Lattre <alexis.delattre@akretion.com>
during the Akretion-Camptocamp code sprint of June 2011.

Contributors
============

 * Alexis de Lattre (Akretion)
 * Guewen Baconnier (Camptocamp)
 * Nicolas Bessi (Camptocamp)
