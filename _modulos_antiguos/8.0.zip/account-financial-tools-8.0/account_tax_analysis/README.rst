Tax analysis view
=================

This add-on is a must if you want to be able to validate your VAT form.

Thanks to a new menu 'Invoicing / Reporting / Generic Reporting / Taxes / Taxes Analysis'
you are able to group accounting entries by Taxes (VAT codes)
and/or financial accounts.

This way you will find easily differences you may see between
the OpenERP tax report and what you see in your books.

Contributors
============

 * Vincent Renaville (Camptocamp SA)
